Área Financiero-Contable (Departamento Contabilidad)

Para el envío de las horas y órdenes para facturar a los clientes: facturacion@ebone.es

Para el envío de facturas de proveedores de los contratos/ventas/cursos: proveedores@ebone.es

Para el envío de facturas de proveedores de gastos generales: jjimenez@ebone.es

Por favor, reenviad el mail a los integrantes de vuestros departamentos, sobre todo en el Área de Operaciones, para que les llegue a todos los DT que nos mandan facturas. 

Os dejo nuestros correos nominativos para cualquier otra gestión:

JACOB JIMENEZ: jjimenez@ebone.es

CRISTINA TAPIADOR: ctapiador@ebone.es

GLORIA VARGAS: gvargas@ebone.es

ANA PUERTA: apuerta@ebone.es

MARIA HINOJOSA: mhinojosa@ebone.es